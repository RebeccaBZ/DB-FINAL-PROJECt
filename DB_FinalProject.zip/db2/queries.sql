create database bussys;
Use  bussys;

CREATE TABLE IF NOT EXISTS STUDENT  
(
  student_id DECIMAL(9,0) NOT NULL,  
  student_firstname VARCHAR(40),
  student_lastname VARCHAR(40),
  student_mobileNb VARCHAR(8),
  student_email VARCHAR(50),
  PRIMARY KEY(student_id)
);

INSERT INTO STUDENT VALUES (202002222, "John", "Doe", "79032802", "john.doe@lau.edu");
INSERT INTO STUDENT VALUES (202020102, "Rebecca", "Bou Zerdan", "70282638", "rebecca.bouzerdan@lau.edu");
INSERT INTO STUDENT VALUES (202092370, "Razan", "Houdaifa", "78671865", "razan.houdaifa@lau.edu");
INSERT INTO STUDENT VALUES (201986521, "Yara", "Hamad", "81973976", "yara.hamad@lau.edu");
SELECT * FROM STUDENT;

CREATE TABLE IF NOT EXISTS BUS_STOP  
(
  stop_id DECIMAL(3,0) NOT NULL,  
  stop_location VARCHAR(50),
  PRIMARY KEY (stop_id)
);
INSERT INTO BUS_STOP VALUES (001, "Jounieh");
INSERT INTO BUS_STOP VALUES (002, "Sarba");
INSERT INTO BUS_STOP VALUES (003, "Dbayeh");
INSERT INTO BUS_STOP VALUES (007, "Naccache");
INSERT INTO BUS_STOP VALUES (004, "Nahr el Mot");
INSERT INTO BUS_STOP VALUES (005, "Verdun");
INSERT INTO BUS_STOP VALUES (006, "Adlieh");
SELECT * FROM BUS_STOP;

CREATE TABLE IF NOT EXISTS BUS
(
  bus_id DECIMAL(3,0) NOT NULL,  
  bus_model VARCHAR(40),
  bus_capacity DECIMAL(2,0),
  bus_features VARCHAR(40),
  company_id DECIMAL(3,0),
  PRIMARY KEY(bus_id),
  FOREIGN KEY (company_id) REFERENCES COMPANY(company_id)
  
);

INSERT INTO BUS VALUES( 001, "C2000", 50, "airconditionined", 002);
INSERT INTO BUS VALUES( 003, "C2001", 30, "airconditioned", 002);
INSERT INTO BUS VALUES( 004, "C2030", 48, "available curtains", 001);
INSERT INTO BUS VALUES( 005, "C2001", 38, "airconditioned", 002);

select * FROM BUS;

CREATE TABLE IF NOT EXISTS BUS_STAT
(
  bus_id DECIMAL(3,0) NOT NULL,  
  stop_id DECIMAL(3,0) NOT NULL,
  PRIMARY KEY(bus_id, stop_id),
  FOREIGN KEY (bus_id) REFERENCES BUS(bus_id),
  FOREIGN KEY (stop_id) REFERENCES BUS_STOP(stop_id)
);

INSERT INTO BUS_STAT VALUES(001, 001);
INSERT INTO BUS_STAT VALUES(003, 003);
INSERT INTO BUS_STAT VALUES(003, 006);
INSERT INTO BUS_STAT VALUES(001, 005);
INSERT INTO BUS_STAT VALUES(001, 002);

SELECT * FROM BUS_STAT;

CREATE TABLE IF NOT EXISTS DRIVER  
(
  driver_id DECIMAL(3,0) NOT NULL,  
  driver_firstname VARCHAR(40),
  driver_lastname VARCHAR(40),
  driver_mobileNb VARCHAR(8),
  driver_email VARCHAR(50),
  bus_id DECIMAL(3,0),
  PRIMARY KEY(driver_id),
  FOREIGN KEY(bus_id) REFERENCES BUS(bus_id)
);

INSERT INTO DRIVER VALUES(001, "Hussein", "Zayat", "81973972", "hussein.zayat@lau.edu",001);
INSERT INTO DRIVER VALUES(002, "Issam", "Zein", "80973972", "issam.zein@lau.edu",003);
INSERT INTO DRIVER VALUES(003, "Youssef", "Mouawad", "81943972", "youssef.mouawad@lau.edu",001);

CREATE TABLE IF NOT EXISTS SEAT
(
  seat_id DECIMAL(3,0) NOT NULL,  
  seat_nb DECIMAL(2,0),
  bus_id DECIMAL(3,0), 
  PRIMARY KEY(seat_id),
  FOREIGN KEY (bus_id) REFERENCES BUS(bus_id)
);

INSERT INTO SEAT VALUES(001, 10, 003);
INSERT INTO SEAT VALUES(002, 20, 003);
INSERT INTO SEAT VALUES(003, 11, 003);
INSERT INTO SEAT VALUES(004, 34, 003);
INSERT INTO SEAT VALUES(005, 34, 001);

SELECT * FROM SEAT;

CREATE TABLE IF NOT EXISTS COMPANY
(
  company_id DECIMAL(3,0) NOT NULL,
  company_name VARCHAR(40), 
  company_phoneNb VARCHAR(8),
  PRIMARY KEY(company_id)
);

INSERT INTO COMPANY VALUES(001, "KHOURY TRANSPORT", "04816891");
INSERT INTO COMPANY VALUES(002, "ISSA TRANSPORT", "04836891");

CREATE TABLE IF NOT EXISTS MANAGER  
(
  manager_id DECIMAL(3,0) NOT NULL,  
  manager_firstname VARCHAR(40),
  manager_lastname VARCHAR(40),
  manager_mobileNb VARCHAR(8),
  manager_email VARCHAR(50), 
  start_date DATE, 
  PRIMARY KEY(manager_id)
);

INSERT INTO MANAGER VALUES(001, "Naim", "Saliba", "04829712", "naim.saliba@lau.edu", "2020-02-02");
INSERT INTO MANAGER VALUES(002, "George", "Saba", "04825712", "george.saba@lau.edu", "2021-03-01");

CREATE TABLE IF NOT EXISTS WORK  
(
  manager_id DECIMAL(3,0) NOT NULL,  
  company_id DECIMAL(3,0) NOT NULL,
  driver_id DECIMAL(3,0) NOT NULL,
  PRIMARY KEY(manager_id, company_id, driver_id),
  FOREIGN KEY (manager_id) REFERENCES MANAGER(manager_id),
  FOREIGN KEY (company_id) REFERENCES COMPANY(company_id),
  FOREIGN KEY (driver_id) REFERENCES DRIVER(driver_id)
);

INSERT INTO WORK VALUES(001, 001, 001);
INSERT INTO WORK VALUES(002,001,003);
INSERT INTO WORK VALUES(002,002,001);
INSERT INTO WORK VALUES(002,002,003);

CREATE TABLE IF NOT EXISTS DESTINATION
(
  destination_id DECIMAL(3,0) NOT NULL,  
  start_location VARCHAR(40),
  end_location VARCHAR(40),
  PRIMARY KEY(destination_id)
);

INSERT INTO DESTINATION VALUES(001, "Beirut", "Jbeil");
INSERT INTO DESTINATION VALUES(002, "Jbeil", "Beirut");
INSERT INTO DESTINATION VALUES(003, "Jbeil", "Tripoli");

CREATE TABLE IF NOT EXISTS ROUTE
(
  route_id DECIMAL(3,0) NOT NULL,  
  start_location VARCHAR(40),
  end_location VARCHAR(40),
  PRIMARY KEY(route_id)
);

INSERT INTO ROUTE VALUES(001, "Jbeil", "Jounieh");
INSERT INTO ROUTE VALUES(002, "Jbeil", "Tripoli");

CREATE TABLE IF NOT EXISTS DESTINATION_MANAGER  
(
  manager_id DECIMAL(3,0) NOT NULL,  
  destination_id DECIMAL(3,0) NOT NULL,
  duration DECIMAL (2,0),
  PRIMARY KEY(manager_id, destination_id, duration),
  FOREIGN KEY (manager_id) REFERENCES MANAGER(manager_id),
  FOREIGN KEY (destination_id) REFERENCES DESTINATION(destination_id)
);

INSERT INTO DESTINATION_MANAGER VALUES (001, 001, 5);
INSERT INTO DESTINATION_MANAGER VALUES (002, 002, 10);

CREATE TABLE IF NOT EXISTS ROUTE_DESTINATION  
(
  route_id DECIMAL(3,0) NOT NULL,  
  destination_id DECIMAL(3,0) NOT NULL,
  PRIMARY KEY(route_id, destination_id),
  FOREIGN KEY (route_id) REFERENCES ROUTE(route_id),
  FOREIGN KEY (destination_id) REFERENCES DESTINATION(destination_id)
);

INSERT INTO ROUTE_DESTINATION VALUES (001, 002);
INSERT INTO ROUTE_DESTINATION VALUES (001, 003);

CREATE TABLE IF NOT EXISTS ROUTING  
(
  route_id DECIMAL(3,0) NOT NULL,  
  stop_id DECIMAL(3,0) NOT NULL,
  PRIMARY KEY(route_id, stop_id),
  FOREIGN KEY (route_id) REFERENCES ROUTE(route_id),
  FOREIGN KEY (stop_id) REFERENCES BUS_STOP(stop_id)
);

INSERT INTO ROUTING VALUES (001, 002);
INSERT INTO ROUTING VALUES (001, 003);


CREATE TABLE IF NOT EXISTS RESERVATION  
(
  reservation_id DECIMAL(3,0) NOT NULL,  
  seat_id DECIMAL(3,0) NOT NULL,
  student_id DECIMAL(9,0) NOT NULL,
  departure_time TIME, 
  PRIMARY KEY(reservation_id, seat_id, student_id),
  FOREIGN KEY (seat_id) REFERENCES SEAT(seat_id),
  FOREIGN KEY (student_id) REFERENCES STUDENT(student_id)
);

INSERT INTO RESERVATION VALUES (006, 001, 202002222, "13:00:00");
INSERT INTO RESERVATION VALUES (002, 002, 202092370, "17:00:00");

SELECT * FROM RESERVATION;

CREATE TABLE IF NOT EXISTS STUDENT_STOP  
(
  student_id DECIMAL(9,0) NOT NULL,  
  stop_id DECIMAL(3,0) NOT NULL,
  PRIMARY KEY(student_id, stop_id),
  FOREIGN KEY (student_id) REFERENCES STUDENT(student_id),
  FOREIGN KEY (stop_id) REFERENCES BUS_STOP(stop_id)
);

INSERT INTO STUDENT_STOP VALUES (202002222, 001);
INSERT INTO STUDENT_STOP VALUES (202020102, 006);
INSERT INTO STUDENT_STOP VALUES (202092370, 005);

SELECT * FROM STUDENT_STOP;

CREATE TABLE IF NOT EXISTS BUS_ROUTE  
(
  departure_time TIME,
  route_id DECIMAL(3,0) NOT NULL,  
  bus_id DECIMAL(3,0) NOT NULL,
  PRIMARY KEY(departure_time, route_id, bus_id),
  FOREIGN KEY (route_id) REFERENCES ROUTE(route_id),
  FOREIGN KEY (bus_id) REFERENCES BUS(bus_id)
);

INSERT INTO BUS_ROUTE VALUES("6:00:00", 001, 003);
INSERT INTO BUS_ROUTE VALUES("13:00:00", 002, 003);
INSERT INTO BUS_ROUTE VALUES("17:00:00", 001, 001);
INSERT INTO BUS_ROUTE VALUES("20:00:00", 002, 001);

SELECT * FROM BUS_ROUTE;


-- Some examples of queries which are useful for this project 
-- to retrieve the info regarding the logged in student
SELECT * FROM STUDENT WHERE student_email="rebecca.bouzerdan@lau.edu";
-- to check the students available at a specific station using station_id
SELECT S.student_firstname, S.student_lastname FROM STUDENT S, STUDENT_STOP D WHERE S.student_id=D.student_id AND D.stop_id=1;

-- to check the students who want to be dropped at a specific location
SELECT student_firstname, student_lastname FROM STUDENT S, STUDENT_STOP D, BUS_STOP B WHERE S.student_id=D.student_id AND D.stop_id=B.stop_id AND B.stop_location="Verdun";
 
 -- to find the number of seats reserved in each bus and hence find the capacities
SELECT bus_id, COUNT(reservation_id) FROM SEAT S, RESERVATION R WHERE S.seat_id= R.seat_id GROUP BY bus_id ;

-- to select the info about the driver in case the student wants to contact him
SELECT driver_firstname, driver_lastname, driver_mobileNb, driver_email FROM DRIVER D, BUS B WHERE D.bus_id= B.bus_id AND D.bus_id= 3;

-- to check the location at which a bus will stop based on the model 
SELECT B.stop_location, S.stop_id FROM BUS_STOP B, BUS_STAT S, BUS U WHERE B.stop_id=S.stop_id AND S.bus_id=U.bus_id AND U.bus_model="C2001";





 



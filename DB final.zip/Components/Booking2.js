import React from 'react';
import './Booking.css';
import img1 from './lau.png';
import img2 from './lau.png';




 
export class Booking2 extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            cities : [],
            regions : [],
            spots : [],

            selectedCity : 'City',
            selectedRegion : 'State'
        };
        this.changeCity = this.changeCity.bind(this);
        this.changeRegion = this.changeRegion.bind(this);

    }
    
   
    componentDidMount() { 
        this.setState({
            cities : [
                { name: 'Beirut', regions: [ 
                    {name: 'LAU Beirut', spots: ['LAU Lower Gate']},
                    {name: 'Verdun', spots: ['Al Rifai', 'Goodies']},
                    {name: 'Mar-Elias', spots: ['Moulin dor', 'Thakkanat El Helou']},
                    {name: 'Naccache', spots: ['Naccahe Bridge', 'Mouchet Bridge']}
                ]},
                { name: 'Tripoli', regions: [ 
                    {name: 'Mina', spots: ['Spinneys']},
                    {name: 'Zawiyat Al Dahmani', spots: ['BLOM Bank', 'Tripoli Square']},
                    {name: 'Istiqlal', spots: ['Fransa Bank', 'Plazza Shopping Center']}
                    
                ]},
                     
            ]
        });
    }
   
    changeCity(event) {
        this.setState({selectedCity: event.target.value});
        this.setState({regions : this.state.cities.find(cty => cty.name === event.target.value).regions});
    }
 
    changeRegion(event) {
        this.setState({selectedRegion: event.target.value});
        const stats = this.state.cities.find(cty => cty.name === this.state.selectedCity).regions;
        this.setState({spots : stats.find(reg => reg.name === event.target.value).spots});
    }
    
      
    
     
    render() {
        return (
            

            <div class= "main5">
               <div class="navbar5"> 

                <div class="icon5">
                <img src={img1} /> </div>
            
                <div class="menu5">
                <ul>
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="Bookings.html">BOOKINGS</a></li>
                    <li><a href="profile.html">PROFILE</a></li>
                    <li><a href="#">CONTACT</a></li>
                    <li><a href="#">SETTINGS</a></li>
                    <li><a href="signin.html">SIGNIN</a></li>
                </ul>
                </div>
                </div>
                

                 <div class="content5">

                 <div class="image5">
                    <img src={img2}/>
                </div>
                <br/><br/>
                <div class="title5">
                    My Bookings
                </div>


                <div class="form5">

                    <h1>Ride Back</h1>
                    <div class="inputs5">
                         <label >City</label>
                    <select className="form-select" placeholder="Country" value={this.state.selectedCity} onChange={this.changeCity}>
                        <option>---Select---</option>
                        {this.state.cities.map((e, key) => {
                            return <option key={key}>{e.name}</option>;
                        })}
                    </select>
                    
                    </div>


                    <div class="inputs5">
                       <label >Region</label>
                        <select className="form-select" placeholder="State" value={this.state.selectedRegion} onChange={this.changeRegion}>
                        <option>---Select---</option>
                        {this.state.regions.map((e, key) => {
                            return <option key={key}>{e.name}</option>;
                        })}
                    </select>

                    </div>
                    
                    
                    <div class="inputs5">
                        
                    <label >Spot</label>
                    <select className="form-select" placeholder="City" onChange= "disableTime(this)">
                        <option>---Select---</option>
                        {this.state.spots.map((e, key) => {
                            return <option value ="1" key={key}>{e}</option>;
                            
                        })}
                    </select>
                    </div>
                    
                    <div class="inputs5">
                         <label >Time</label>
                    <select id="f" disabled="">
                        <option>---Select---</option>
                        <option value="1t">1:00</option>
                        <option value="5t">5:00</option>
                        <option value="8t">8:00</option>
                    </select>

                    </div>

                </div>

                <button class="discard"><a href="index.html">Back</a></button>
                <button class="update"><a href="">Submit</a></button>
                </div>
                

                <div class="footer5">
                <p class="bei"><b>Beirut Campus</b> <br/> P.O. Box 13-5053,Chouran
                    <br/>Beirut: 1102 2801
                    <br/>Tel.: 01-786456,
                    <br/>Fax: 01-867098
                </p>

                <p class="byb"><b>Byblos Campus</b><br/>P.O. Box 36, Byblos
                    <br/>Tel.: 09-547254,
                    <br/>Fax: 09-944851<br/>
                </p>

                <p class="ny"><b>New York Headquarters</b><br/>211 East 46th Street
                    <br/>New York, N.Y. 10017
                    <br/>Tel.: (212) 203 4333
                    <br/>Fax: (212) 784 6597
                </p>

                </div>

                
                </div>
            

            
        )
    }
}
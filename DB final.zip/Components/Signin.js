import React from 'react';
import './Signin.css';
import img1 from './lau.png';

export class Signin extends React.Component{
  
render() {
        return (

        <div class="center3">
        <img src={img1}></img>

            <form method="post3">
            <div class="txt_feild3">
                <input type="text" required/>
                <span></span>
                <label>Username</label>
            </div>

            <div class="txt_feild3">
                <input type="password" required/>
                <span></span>
                <label>Password</label>
            </div>

            <div class="pass3">Forgot Password?</div>
            
            <button class="sub3"><a href="">Sign In</a></button>
            <div class="signUp_link3">Not Registered?<a href="#"> Sign Up</a></div>
            
        </form>
        </div>

        )}}
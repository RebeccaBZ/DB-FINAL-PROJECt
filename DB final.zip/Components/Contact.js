import React from 'react';
import './Home.css';
import img1 from './lau.png';

export class Contact extends React.Component{
  
render() {
        return (
            <div class="main6">

            <div class="navbar6">
            <div class="icon6">
                <img src={img1}/>
            </div>
            <div class="menu6">
                <ul>
                    <li><a href="">HOME</a></li>
                    <li><a href="">BOOKINGS</a></li>
                    <li><a href="">PROFILE</a></li>
                    <li><a href="#">CONTACT</a></li>
                    <li><a href="#">SETTINGS</a></li>
                    <li><a href="signin.html">SIGNIN</a></li>


                </ul>
            </div>
            </div>
            

             <div class="content6">
            <h1><br/>Questions? <br/> Contact the Logistics Departments</h1>
            <p class="par">Byblos: logictics.byblos@lau.edu  
                           ext.2094 <br/>
                           Beirut: logictics.beirut@lau.edu
                           ext.5011
                              
            </p>
            <br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
            
        </div>

        

        <div class="footer6">
            <p class="bei"><b>Beirut Campus</b> <br/> P.O. Box 13-5053,Chouran
                <br/>Beirut: 1102 2801
                <br/>Tel.: 01-786456,
                <br/>Fax: 01-867098
            </p>

            <p class="byb"><b>Byblos Campus</b><br/>P.O. Box 36, Byblos
                <br/>Tel.: 09-547254,
                <br/>Fax: 09-944851<br/>
            </p>

            <p class="ny"><b>New York Headquarters</b><br/>211 East 46th Street
                <br/>New York, N.Y. 10017
                <br/>Tel.: (212) 203 4333
                <br/>Fax: (212) 784 6597
            </p>
        </div>
    </div>


        )}}
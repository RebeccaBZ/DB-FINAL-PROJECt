import React from 'react';
import './Profile.css';
import img1 from './lau.png';
import img2 from './lau.png';

export class Profile extends React.Component{
  
render() {
        return (
            <div class="main">

 
    <div class="navbar">
       <div class="icon">
         <img src={img2} />
            </div>
            
            <div class="menu">
                <ul>
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="Bookings.html">BOOKINGS</a></li>
                    <li><a href="profile.html">PROFILE</a></li>
                    <li><a href="#">CONTACT</a></li>
                    <li><a href="#">SETTINGS</a></li>
                    <li><a href="signin.html">SIGNIN</a></li>


                </ul>
            </div>
            </div>

<div class="content">
             <div class="image">
                <img src={img1} />
                </div>
                <br/><br/>
            <div class="title">
                My Profile
            </div>

            <div class="form">

            <div class="inputs">
                    <label>User ID</label>
                    <input type="text"/>
                    <span></span>
                </div>
                <div class="inputs">
                    <label>User Name</label>
                    <input type="text"/>
                    <span></span>
                </div>
                

                <div class="inputs">
                    <label>Full Name</label>
                    <input type="text"/>
                    <span></span>
                </div>

                <div class="inputs">
                    <label>First Name</label>
                    <input type="text"/>
                    <span></span>
                </div>


                 <div class="inputs">
                    <label>Last Name</label>
                    <input type="text"/>
                    <span></span>
                </div>

                <div class="inputs">
                    <label>Middle Name</label>
                    <input type="text"/>
                    <span></span>
                </div>
                

                <div class="inputs">
                    <label>Birth Date</label>
                    <input type="date"/>
                    <span></span>
                </div>

                <div class="inputs">
                    <label>Phone Number</label>
                    <input type="number"/>
                    <span></span>
                </div>

                <div class="inputs">
                <label>Email Address</label>
                <input type="text"/>
                <span></span>
                </div>


                <div class="inputs">
                    <label>Address</label>
                    <textarea class="textarea"></textarea>
                    <span></span>
                </div>

                <div class="inputs">
                    <label>Password</label>
                    <input type="password"/>
                    <span></span>
                </div>

                
                </div>
                <button class="discard"><a href="index.html">Back</a></button>
                <button class="update"><a href="">Update</a></button>

                </div>

            <div class="footer">
                <p class="bei"><b>Beirut Campus</b> <br/> P.O. Box 13-5053,Chouran
                    <br/>Beirut: 1102 2801
                    <br/>Tel.: 01-786456,
                    <br/>Fax: 01-867098
                </p>
            
                <p class="byb"><b>Byblos Campus</b><br/>P.O. Box 36, Byblos
                    <br/>Tel.: 09-547254,
                    <br/>Fax: 09-944851<br/>
                </p>
            
                <p class="ny"><b>New York Headquarters</b><br/>211 East 46th Street
                    <br/>New York, N.Y. 10017
                    <br/>Tel.: (212) 203 4333
                    <br/>Fax: (212) 784 6597
                </p>
             
             </div>
            
             
               </div> 
            

        )}}
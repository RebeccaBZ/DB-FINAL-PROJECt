import React from 'react';
import './Denied.css';
import img1 from './lau.png';

export class Denied extends React.Component{
  
render() {
        return (
        <div class="center4">
        
        
        <div class="denied4">
            <img src={img1} alt="LAU logo"/>
            <br/><br/>
            <h1>Access Denied</h1>
            <h2>Wrong Username or Password</h2>
            <br/><br/>
         </div>
         <div class="pass">Forgot Password?</div> <br/><br/>
            <button class="back"><a href="signin.html">Back</a></button>
            <div class="signUp_link">Not Registered?<a href="#"> Sign Up</a></div>
          

            </div>
        
        
        )}}
#create a DB models for our users and notes
from .import db
from flask_login import UserMixin
from sqlalchemy.sql import func

#initiating the components of the DB
class Student(db.Model, UserMixin):
    student_id=db.Column(db.Integer, primary_key=True)
    student_firstName=db.Column(db.String(50))
    student_lastName=db.Column(db.String(50))
    student_mobileNB=db.Column(db.Integer(8),unique=True)
    student_email= db.Column(db.String(150), unique= True)

    reserves=db.relationship('Seat')
    specifies=db.relationship('Bus_stop')

class Seat(db.Model):
    seat_id=db.Column(db.Integer, primary_key=True)
    seat_nb=db.Column(db.Integer(2))

class Reservation(db.Model):
    reservation_id=db.Column(db.Integer, primary_key=True)
    departure_time=db.Column(db.DateTime(timezone=True), default=func.fromisformat)

    student_id=db.Column(db.Integer,db.ForeignKey('student.student_id'))
    seat_id=db.Column(db.Integer,db.ForeignKey('seat.seat_id'))
    

class Bus(db.Model):
    bus_id=db.Column(db.Integer, primary_key=True)
    bus_model=db.Column(db.String(50))
    bus_capacity=db.Column(db.Integer(2))
    bus_features=db.Column(db.String(150))

    contains=db.relationship('Seat')
    hasRoute=db.relationship('Route')
    stops=db.relationship('Bus_Stop')

class Driver(db.Model,UserMixin):
    driver_id=db.Column(db.Integer, primary_key=True)
    driver_firstName=db.Column(db.String(50))
    driver_lastName=db.Column(db.String(50))
    driver_mobileNB=db.Column(db.Integer(8), unique=True)
    driver_email= db.Column(db.String(150), unique= True)

    drives=db.relationship('Bus')
    worksWith=db.relationship('Company','Manager')

class Manager(db.Model):
    manager_id=db.Column(db.Integer, primary_key=True)
    manager_firstName=db.Column(db.String(50))
    manager_lastName=db.Column(db.String(50))
    manager_mobileNB=db.Column(db.Integer(8))
    manager_email= db.Column(db.String(150), unique= True)
    manager_startdate=db.Column(db.DateTime(timezone=True), default=func.fromisformat)

    worksWith=db.relationship('Driver','Manager')
    indicates=db.relationship('Destination')

class Company(db.model):
    company_id=db.Column(db.Integer, primary_key=True)
    company_name=db.Column(db.String(50))
    company_mobileNB=db.Column(db.Integer(8), unique=True)

    assigns=db.relationship('Bus')
class Destination(db.Model):
    destination_id=db.Column(db.Integer, primary_key=True)
    destination_location=db.Column(db.String(50))

class Route(db.Model):
    route_id=db.Column(db.Integer, primary_key=True)
    route_startLocation=db.Column(db.String(50))
    route_endLocation=db.Column(db.String(50))

    hasDestination=db.relationship('Destination')
    hasDestination=db.relationship('Destination')

class Bus_Stop(db.Model):
    stop_id=db.Column(db.Integer, primary_key=True)
    stop_location=db.Column(db.String(50))

 

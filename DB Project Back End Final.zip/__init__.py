from flask import Flask
from flask_sqlalchemy import SQLAlchemy 
from os import path
from flask_login import LoginManager

db=SQLAlchemy()
DB_NAME="database.db"
#include the name of our db 

def create_app():

    app=Flask(__name__, template_folder="template")
    app.config['SECRET_KEY']='hello root DB 176892'
    app.config['SQLALCHEMY_DATBASE_URI']= f'sqlite:///{DB_NAME}'
    db.init_app(app)

    
    from .auth import auth
    from .views import views

    app.register_blueprint(views, url_prefix='/')
    app.register_blueprint(auth, url_prefix='/')

   #done correclty from website import models

    #import the entities and relations
    from .models import Student, Bus, Bus_Stop, Manager, Destination, Driver, Reservation, Route, Seat,Company

    create_database(app)

    login_manager= LoginManager()
    login_manager.login_view='auth.login'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(student_id):
        return Student.query.get(int(student_id))

    return app

def create_database(app):
    if not path.exists('website/'+DB_NAME):
        db.create_all(app=app)
        print('Created Database!')

    
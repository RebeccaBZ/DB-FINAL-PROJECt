from flask import Blueprint, render_template, request, flash, redirect, url_for
from .models import Student
from werkzeug.security import generate_password_hash, check_password_hash
from .import db
from flask_login import login_user, login_required, logout_user,current_user


auth = Blueprint('auth', __name__)

#routing to the needed pages to be linked

@auth.route('/home')
def homePage():
   return render_template("home.html")

#using GET and POST to retrieve and add info from/to DB
@auth.route('/login',methods=['GET','POST'])
def login():
    data= request.form
    print(data)
 
    if request.method == 'POST':
      email=request.form.get('email')
      password= request.form.get('password') 

      student=Student.query.filter_by(email=email).first()

    if student:
        if check_password_hash(student.password,password):

            flash('Logged in successfully!', category='success') 
            login_user(student,remember=True)
            return redirect(url_for('views.home')) 
        else:
            flash('Incorrect password, try again', category='error')
        
    else:
        flash('Email does not exist.', category='error')
    return render_template("login.html", student=current_user)

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for(auth.login))
   

@auth.route('/sign-up',methods=['GET','POST'])
def sign_up():
    # in case in our demo we need to let the user sign up then we should include the allowance to add the user to the database 
    return render_template("sign-up.html")

@auth.route('/profile',methods=['GET','POST'])
def profile():
    return render_template("profile.html", student=current_user)

@auth.route('/my-bookings',methods=['GET','POST'])
def my_bookings():
    data= request.form
    print(data)
 
    if request.method == 'POST':
      departureTime=request.form.get('DepartureTime')
      stopLocation= request.form.get('BusStop')
      routestartLocation= request.form.get('routestartLocation')
      timeSlot=request.form.get('timeSlot')

    return render_template("my-booking.html",student=current_user)

@auth.route('/settings',methods=['GET','POST'])
def settings():
    return render_template("settings.html")

@auth.route('/confirmation',methods=['GET','POST'])
def confirmation():
    if request.method == 'GET':
      departureTime=request.form.get('DepartureTime')
      stopLocation= request.form.get('BusStop')
      routestartLocation= request.form.get('routestartLocation')
      timeSlot=request.form.get('timeSlot')
      
    return render_template("confirmation.html", student=current_user)  
    

